-- 2-vazifa --
CREATE TABLE kitoblar (
    id INT PRIMARY KEY,
    nomi VARCHAR(100),
    muallif VARCHAR(100),
    janri VARCHAR(50),
    narxi DECIMAL(10,2),
    nashr_yili INT,
    sahifalar_soni INT
);

INSERT INTO kitoblar VALUES
(1,'Python Asoslari','Akmal','Dasturlash',120000,2021,350),
(2,'SQL Darslari','Akmal','Dasturlash',150000,2022,400),
(3,'Suniy Intellekt','Dilshod','Dasturlash',180000,2023,500),
(4,'Sirli Uy','Jasur','Roman',90000,2020,250),
(5,'Yoqolgan Shahar','Jasur','Roman',100000,2021,300),
(6,'Osiyo Tarixi','Sardor','Tarix',130000,2019,450),
(7,'Ikkinchi Jahon Urushi','Sardor','Tarix',160000,2022,550),
(8,'Zamonaviy AI','Dilshod','Dasturlash',220000,2024,600),
(9,'Sevgi Qissasi','Madina','Romantika',80000,2021,220),
(10,'Orzular','Madina','Romantika',95000,2023,280);

SELECT muallif, COUNT(*) AS kitoblar_soni
FROM kitoblar
GROUP BY muallif;

SELECT janri, COUNT(*) AS kitoblar_soni
FROM kitoblar
GROUP BY janri;

SELECT muallif, AVG(narxi) AS ortacha_narx
FROM kitoblar
GROUP BY muallif;

SELECT janri, MAX(narxi) AS eng_qimmat_narx
FROM kitoblar
GROUP BY janri;

SELECT nashr_yili, COUNT(*) AS kitoblar_soni
FROM kitoblar
GROUP BY nashr_yili;

SELECT muallif, SUM(sahifalar_soni) AS jami_sahifalar
FROM kitoblar
GROUP BY muallif;

SELECT janri, AVG(sahifalar_soni) AS ortacha_sahifalar
FROM kitoblar
GROUP BY janri;