-- 1-vazifa --
CREATE DATABASE universitet;
USE universitet;

CREATE TABLE student_groups (
    id INT PRIMARY KEY,
    group_name VARCHAR(50)
);

INSERT INTO student_groups VALUES
(1,'N12'),
(2,'N15'),
(3,'N18');

CREATE TABLE students (
    id INT PRIMARY KEY,
    name VARCHAR(50),
    group_id INT,
    FOREIGN KEY (group_id) REFERENCES student_groups(id)
);

INSERT INTO students VALUES
(1,'Ali',1),
(2,'Vali',2),
(3,'Sardor',1),
(4,'Madina',3),
(5,'Aziza',NULL);

CREATE TABLE grades (
    id INT PRIMARY KEY,
    student_id INT,
    grade INT,
    FOREIGN KEY (student_id) REFERENCES students(id)
);

INSERT INTO grades VALUES
(1,1,95),
(2,2,88),
(3,3,92),
(4,4,76);

CREATE TABLE subjects (
    id INT PRIMARY KEY,
    subject_name VARCHAR(50)
);

INSERT INTO subjects VALUES
(1,'Matematika'),
(2,'Ingliz tili'),
(3,'Fizika'),
(4,'Kimyo');

SELECT s.name, g.group_name
FROM students s
INNER JOIN student_groups g
ON s.group_id = g.id;

SELECT s.name, gr.grade
FROM students s
LEFT JOIN grades gr
ON s.id = gr.student_id;

SELECT sub.subject_name, gr.grade
FROM grades gr
RIGHT JOIN subjects sub
ON gr.id = sub.id;

SELECT s.name, gr.grade
FROM students s
INNER JOIN grades gr
ON s.id = gr.student_id
WHERE gr.grade > 90;